#!/usr/bin/env python

"""
Author : Souvik Das
Registration number : 920107172010
"""

"""
A program to parse a PDB file to get the amino acid
sequence.

The three letter amino acid is converted to its
corresponding a one-letter code.
"""

from sys import argv

##
def parse_PDB_file(input_PDB_file):

    """
    This function takes the PDB file as input parameter.

    It returns a list of all the three letter code amino
    acid residues.
    """
    sequence = []

    for line in input_PDB_file:
        if line.startswith('SEQRES') or line[0:6] == 'SEQRES':
            columns = line.split()
            for residues in columns[4:]:
                sequence += [residues]

    return sequence

##
def convert_sequence(seq_list):
    """
    This function takes in the list containing the three-letter
    code of every amino acid as an input parameter.

    It returns a string of the single-letter code of the
    amino acid in the list.
    """
    aa_codes = {
        'ALA':'A','CYS':'C','ASP':'D','GLU':'E',
        'PHE':'F','GLY':'G','HIS':'H','LYS':'K',
        'ILE':'I','LEU':'L','MET':'M','ASN':'N',
        'PRO':'P','GLN':'Q','ARG':'R','SER':'S',
        'THR':'T','VAL':'V','TYR':'Y','TRP':'W'
        }

    protein = ''
    
    for residues in seq_list:
        protein += aa_codes[residues]

    return protein

if __name__ == '__main__':

    PDB_file = open('1TLD.pdb','r')
    seq_list = parse_PDB_file(PDB_file)
    protein = convert_sequence(seq_list)
    print protein
